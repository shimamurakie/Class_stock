<?php

function hoge() {
  $i = $i + 1;
  var_dump($i);
}
//
hoge();
hoge();
hoge();
hoge();

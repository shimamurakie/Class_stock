<?php

ini_set('display_errors', 'on');
error_reporting(E_ALL);

function test() {
}
// XXX 関数の二重定義
function test() {
}

<?php

// 配列の作成
$awk = array(
  'a' => 10,
  'b  => 20,
  'c' => 30,
);

// 確認用の出力
var_dump($awk);

<?php

function dump_string($s)
{
  $len = strlen($s);
  $ret = $s . '(';
  for($i = 0; $i < $len; $i ++) {
    $ret .= sprintf("(%02x)", ord($s[$i]));
  }
  $ret .= ')';
  return $ret;
}

// テスト
echo dump_string('あ');

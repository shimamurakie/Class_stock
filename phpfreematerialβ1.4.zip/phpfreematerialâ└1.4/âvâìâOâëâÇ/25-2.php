<?php
// sessionを使うので、出力バッファリングをしておく
ob_start();
session_start();

// XXX 本来ならここで、入力されたID(email)とパスワードを比較する
$id = 'id';

// id(email)とパスワードが一致したと仮定して、ログイン処理
$_SESSION['user_id'] = $id;
session_regenerate_id(true); // セッションフィクセイションなどの防御用

//
ob_end_flush();
?>
ログイン処理をしました！

<!DOCTYPE HTML>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>どこかのPage</title>
</head>

<body>
<?php include("4-2_header.html"); ?>
<h1>どこかのPage</h1>
適当なコンテンツ
<?php include("4-2_fooder.html"); ?>
</body>
</html>

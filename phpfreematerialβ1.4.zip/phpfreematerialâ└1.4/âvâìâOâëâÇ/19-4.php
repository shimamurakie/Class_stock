<?php

// global変数
$a = 10;

function hoge() {
  var_dump($a); // function内なので、globalな$aは参照できない
}

//
hoge();

<?php

// わかりやすいように少しタイムラグを入れる
sleep(3);

// 別のサイトに移動させる
header('Location: http://www.phpexam.jp/');


<?php

//
$string = 'abcfoobarhogebar';
$ret = preg_match('/[^foo]bar/', $string, $matches);
var_dump($ret);
var_dump($matches);

<?php

//
$string = "javascript code\nhttp://example.com";
$ret = preg_match('/^http:/m', $string, $matches);
var_dump($ret);
var_dump($matches);

//
$string = "0123\n";
$ret = preg_match('/[0-9]$/', $string, $matches);
var_dump($ret);
var_dump($matches);

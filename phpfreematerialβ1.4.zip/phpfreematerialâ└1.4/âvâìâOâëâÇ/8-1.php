<?php

for($i = 1; $i <= 31; $i ++) {
  // �o��
  echo "<option value='" , $i , "'>" , $i , "</option>\n";
}

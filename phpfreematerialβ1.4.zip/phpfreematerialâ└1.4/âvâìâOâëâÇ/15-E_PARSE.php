<?php

ini_set('display_errors', 'on');
error_reporting(E_ALL);

echo 'test' // ; 忘れ
echo 'test';

<?php
ini_set('display_errors', 'on');
error_reporting(E_ALL);

$a = 10;
var_dump($A); // 小文字ではなく大文字のAを指定している

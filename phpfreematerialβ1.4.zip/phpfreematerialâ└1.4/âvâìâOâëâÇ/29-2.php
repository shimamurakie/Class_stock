<?php

// 引数の表示
var_dump($argv);

// 標準入力からの情報の受け取り
$stdin_string = file_get_contents('php://stdin');
var_dump($stdin_string);


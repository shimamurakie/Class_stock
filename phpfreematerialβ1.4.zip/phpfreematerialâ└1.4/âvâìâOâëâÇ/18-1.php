<?php

$awk = array (
  1 => 'a',
  2 => 'a',
  0 => 'a',
  3 => 'a',
);
var_dump($awk);

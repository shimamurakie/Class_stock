<?php

// 配列の作成
$awk = array(1,2,3,4,5)

// 確認用の出力
var_dump($awk);

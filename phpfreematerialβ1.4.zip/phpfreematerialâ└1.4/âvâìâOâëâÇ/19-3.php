<?php

// これは正しい
function hoge($a, $b = 10) {
}

// これも正しい
function foo($a = NULL, $b = 'ok') {
}

// これは間違い
function bar($a = false, $b) {
}

// これも間違い
function hogefoo($a = false, $b, $c = 10) {
}

// これは正しい
function hogebar($a = false, $b = 'ok', $c = 10) {
}

//
hoge(10);
foo('aaa');
hogebar();
// 以下、エラーとなる
bar(10);
hogefoo(20);


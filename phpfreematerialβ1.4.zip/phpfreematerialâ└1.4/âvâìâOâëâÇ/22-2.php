<?php

//
$string = '0123456789abcdefghijk';
$ret = preg_match('/a.c./', $string, $matches);
var_dump($ret);
var_dump($matches);


<?php

ini_set('display_errors', 'on');
error_reporting(E_ALL);

// 初期化していない変数に対して演算をしている
$i ++;

<?php

// 誤った実装
function comparison($a, $b) {
  if ( false == strpos($a, $b) ) {
    echo "'{$a}'の中に'{$b}'は含まれていません\n";
  } else {
    echo "'{$a}'の中に'{$b}'は含まれています\n";
  }
}
// 正しい実装
function comparison_correct($a, $b) {
  if ( false === strpos($a, $b) ) {
    echo "'{$a}'の中に'{$b}'は含まれていません\n";
  } else {
    echo "'{$a}'の中に'{$b}'は含まれています\n";
  }
}



//
echo "call comparison\n";
comparison('abcdefg', 'd');
comparison('abcdefg', 'z');
comparison('abcdefg', 'a');
echo "\n";
//
echo "call comparison_correct\n";
comparison_correct('abcdefg', 'd');
comparison_correct('abcdefg', 'z');
comparison_correct('abcdefg', 'a');

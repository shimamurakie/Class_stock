<!DOCTYPE HTML>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>どこかのPage</title>
</head>

<body>
<?php
/* 広告があれば表示する */
@include("4-1.html");
?>
<h1>どこかのPage</h1>
適当なコンテンツ
</body>
</html>

<?php

//
$string = '.?&%$0a01ab0123abc01234abcde012345abcdef';
//$string = '0a01ab0123abc01234abcde012345abcdef';

// アスタリスク
$ret = preg_match('/\d*/', $string, $matches);
var_dump($ret);
var_dump($matches);

// プラス
$ret = preg_match('/\w+/', $string, $matches);
var_dump($ret);
var_dump($matches);

// ？
$ret = preg_match('/\w?/', $string, $matches);
var_dump($ret);
var_dump($matches);

// {}
$ret = preg_match('/\w{2,3}/', $string, $matches);
var_dump($ret);
var_dump($matches);

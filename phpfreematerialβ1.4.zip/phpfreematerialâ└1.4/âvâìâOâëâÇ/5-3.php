<?php

$s = 'test';
if ( (false === isset($s)or('' === $s) ) {
  echo "変数にデータが入っていません\n";
}
//
echo 'program fin';

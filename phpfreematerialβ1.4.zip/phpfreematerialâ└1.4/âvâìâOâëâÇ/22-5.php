<?php

//
$string = '0123456789abcdefghijka.c';
$ret = preg_match('/[a-z]/', $string, $matches);
var_dump($ret);
var_dump($matches);
